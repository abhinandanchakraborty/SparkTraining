package com.streaming.SparkStreaming

object Test extends App {
  println("Test")
}