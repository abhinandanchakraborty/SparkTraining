package com.streaming.SparkStreaming

import org.apache.spark._
import org.apache.spark.streaming._
import org.apache.spark.streaming.StreamingContext._

object SparkStreamingPOC extends App {

  val conf = new SparkConf().setMaster("local[*]").setAppName("MeetupStreaming")
  val ssc = new StreamingContext(conf, Seconds(1))

  val lines = ssc.socketTextStream("stream.meetup.com/2/rsvps", 80)
  lines.print()

  ssc.start() // Start the computation
  ssc.awaitTermination()

}