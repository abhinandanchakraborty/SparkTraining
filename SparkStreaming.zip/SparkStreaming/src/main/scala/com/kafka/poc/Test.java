package com.kafka.poc;

import java.net.*;
import java.io.*;

public class Test {

	public static void main(String[] args) throws Exception
	  {
	    String urlString = "http://stream.meetup.com/2/rsvps";
	    
	    // create the url
	    URL url = new URL(urlString);
	    
	    // open the url stream, wrap it an a few "readers"
	    BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));

	    // write the output to stdout
	    String line;
	    while ((line = reader.readLine()) != null)
	    {
	      System.out.println(line);
	    }

	    // close our reader
	    reader.close();
	  }
}
